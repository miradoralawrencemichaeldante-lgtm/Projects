import sqlite3
import datetime

DB_NAME = "attendance.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


def init_db():
    conn = get_connection()
    c = conn.cursor()

  
    c.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        section TEXT NOT NULL
    )
    """)

   
    c.execute("""
    CREATE TABLE IF NOT EXISTS attendance (
        id TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


def add_student(student_id, name, section):
    conn = get_connection()
    c = conn.cursor()

    try:
        c.execute(
            "INSERT INTO students (id, name, section) VALUES (?,?,?)",
            (student_id, name, section)
        )
        conn.commit()
        success = True
    except sqlite3.IntegrityError:
        success = False  

    conn.close()
    return success

def get_student(student_id):
    conn = get_connection()
    c = conn.cursor()

    c.execute("SELECT id, name, section FROM students WHERE id=?", (student_id,))
    result = c.fetchone()

    conn.close()
    return result 


def record_attendance(student_id):
    today = datetime.date.today().isoformat()
    now = datetime.datetime.now().strftime("%H:%M:%S")

    conn = get_connection()
    c = conn.cursor()

    
    c.execute(
        "SELECT 1 FROM attendance WHERE id=? AND date=?",
        (student_id, today)
    )
    if c.fetchone():
        conn.close()
        return False 

    c.execute(
        "INSERT INTO attendance (id, date, time) VALUES (?,?,?)",
        (student_id, today, now)
    )

    conn.commit()
    conn.close()
    return True

