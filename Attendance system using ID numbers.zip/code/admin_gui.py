import tkinter as tk
from tkinter import messagebox, ttk
from database import add_student
from excel_export import export_all_sections
import subprocess
import sys
import os
import tkinter as tk
from tkinter import messagebox


root = tk.Tk()
root.title("Attendance Admin Panel")
root.geometry("500x400")
root.resizable(False, False)


title = tk.Label(
    root,
    text="STUDENT ATTENDANCE ADMIN",
    font=("Arial", 16, "bold")
)
title.pack(pady=10)


frame = tk.LabelFrame(root, text="Add Student", padx=10, pady=10)
frame.pack(fill="x", padx=20, pady=10)

tk.Label(frame, text="Student ID").grid(row=0, column=0, sticky="w")
tk.Label(frame, text="Full Name").grid(row=1, column=0, sticky="w")
tk.Label(frame, text="Section").grid(row=2, column=0, sticky="w")

entry_id = tk.Entry(frame, width=30)
entry_name = tk.Entry(frame, width=30)
entry_section = tk.Entry(frame, width=30)

entry_id.grid(row=0, column=1, pady=5)
entry_name.grid(row=1, column=1, pady=5)
entry_section.grid(row=2, column=1, pady=5)

def handle_add_student():
    sid = entry_id.get().strip()
    name = entry_name.get().strip()
    section = entry_section.get().strip()

    if not sid or not name or not section:
        messagebox.showerror("Error", "All fields are required")
        return

    if add_student(sid, name, section):
        messagebox.showinfo("Success", "Student added successfully")
        entry_id.delete(0, tk.END)
        entry_name.delete(0, tk.END)
        entry_section.delete(0, tk.END)
    else:
        messagebox.showwarning("Duplicate", "Student ID already exists")

def start_scanner():
    scanner_path = os.path.join(os.getcwd(), "locked_ocr_scanner.py")

    if not os.path.exists(scanner_path):
        messagebox.showerror("Error", "locked_ocr_scanner.py not found!")
        return

    try:
        subprocess.Popen([sys.executable, scanner_path])
    except Exception as e:
        messagebox.showerror("Error", str(e))


btn_add = tk.Button(
    frame,
    text="Add Student",
    command=handle_add_student,
    width=20
)
btn_add.grid(row=3, column=0, columnspan=2, pady=10)


export_frame = tk.LabelFrame(root, text="Reports", padx=10, pady=10)
export_frame.pack(fill="x", padx=20, pady=10)

def handle_export():
    export_all_sections()
    messagebox.showinfo(
        "Export Complete",
        "Excel files exported successfully"
    )

btn_export = tk.Button(
    export_frame,
    text="Export Weekly Attendance (ALL Sections)",
    command=handle_export,
    width=40
)
start_scanner_btn = tk.Button(
    root,
    text="🎥 Start Scanner",
    width=30,
    height=2,
    bg="#4CAF50",
    fg="white",
    command=start_scanner
)
start_scanner_btn.pack(pady=10)

btn_export.pack(pady=5)


btn_exit = tk.Button(root, text="Exit", command=root.destroy)
btn_exit.pack(pady=10)

root.mainloop()
