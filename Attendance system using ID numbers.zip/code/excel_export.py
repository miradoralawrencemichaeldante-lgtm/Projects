import sqlite3
import pandas as pd
import os
import datetime

DB_NAME = "attendance.db"
BASE_FOLDER = "excel_exports"

def export_all_sections():
    conn = sqlite3.connect(DB_NAME)

    
    students = pd.read_sql(
        "SELECT * FROM students ORDER BY name ASC",
        conn
    )

    if students.empty:
        print("❌ No students found")
        conn.close()
        return

   
    today = datetime.date.today()
    monday = today - datetime.timedelta(days=today.weekday())
    friday = monday + datetime.timedelta(days=4)

    
    attendance = pd.read_sql(
        f"""
        SELECT * FROM attendance
        WHERE date BETWEEN '{monday}' AND '{friday}'
        """,
        conn
    )
    conn.close()

    os.makedirs(BASE_FOLDER, exist_ok=True)

    for section in students["section"].unique():
        section_students = students[students["section"] == section]

        records = []

        for _, s in section_students.iterrows():
            
            row = {
                "NAME": s["name"],
                "MONDAY": "",
                "TUESDAY": "",
                "WEDNESDAY": "",
                "THURSDAY": "",
                "FRIDAY": ""
            }

            
            for _, att in attendance[attendance["id"] == s["id"]].iterrows():
                att_date = datetime.datetime.strptime(att["date"], "%Y-%m-%d").date()
                weekday = att_date.weekday()  

                if weekday == 0:
                    row["MONDAY"] = "✔"
                elif weekday == 1:
                    row["TUESDAY"] = "✔"
                elif weekday == 2:
                    row["WEDNESDAY"] = "✔"
                elif weekday == 3:
                    row["THURSDAY"] = "✔"
                elif weekday == 4:
                    row["FRIDAY"] = "✔"

            records.append(row)

        df = pd.DataFrame(records)

        
        section_folder = os.path.join(BASE_FOLDER, section)
        os.makedirs(section_folder, exist_ok=True)

        
        filename = f"{section}_attendance_{today}.xlsx"
        path = os.path.join(section_folder, filename)

        
        df.to_excel(path, index=False)
        print(f"✅ Exported: {path}")


if __name__ == "__main__":
    export_all_sections()
