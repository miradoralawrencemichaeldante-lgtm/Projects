import sqlite3
import datetime
import os
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.styles import Font


DB_NAME = "attendance.db"
EXPORT_BASE_FOLDER = "excel exports"



def get_week_range(date_obj):
    monday = date_obj - datetime.timedelta(days=date_obj.weekday())
    friday = monday + datetime.timedelta(days=4)
    return monday, friday



def get_all_sections(conn):
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT section FROM students ORDER BY section")
    return [row[0] for row in cur.fetchall()]



def fetch_week_attendance(conn, section, monday, friday):
    cur = conn.cursor()
    cur.execute("""
        SELECT s.name, a.date
        FROM attendance a
        JOIN students s ON a.id = s.id
        WHERE s.section = ?
        AND a.date BETWEEN ? AND ?
        ORDER BY s.name
    """, (section, monday.isoformat(), friday.isoformat()))
    return cur.fetchall()



def build_weekly_table(records):
    table = defaultdict(lambda: {
        "Monday": "",
        "Tuesday": "",
        "Wednesday": "",
        "Thursday": "",
        "Friday": ""
    })

    for name, date_str in records:
        date_obj = datetime.date.fromisoformat(date_str)
        day = date_obj.strftime("%A")
        if day in table[name]:
            table[name][day] = "✔"

    return table



def export_weekly_excel(section, weekly_table, monday, friday):
    section_folder = os.path.join(EXPORT_BASE_FOLDER, section)
    os.makedirs(section_folder, exist_ok=True)

    filename = f"{section}_{monday}_to_{friday}.xlsx"
    filepath = os.path.join(section_folder, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = "Weekly Attendance"

    headers = ["NAME", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    ws.append(headers)

    for cell in ws[1]:
        cell.font = Font(bold=True)

    for name in sorted(weekly_table.keys()):
        ws.append([name] + list(weekly_table[name].values()))

    wb.save(filepath)
    print(f"✅ Exported: {filepath}")



def main():
    conn = sqlite3.connect(DB_NAME)

    today = datetime.date.today()
    monday, friday = get_week_range(today)

    sections = get_all_sections(conn)

    if not sections:
        print("❌ No sections found in database.")
        return

    print(f"📚 Exporting attendance for {len(sections)} sections...\n")

    for section in sections:
        records = fetch_week_attendance(conn, section, monday, friday)

        if not records:
            print(f"⚠ No attendance for section: {section}")
            continue

        weekly_table = build_weekly_table(records)
        export_weekly_excel(section, weekly_table, monday, friday)

    conn.close()
    print("\n✅ ALL SECTIONS EXPORTED SUCCESSFULLY")


if __name__ == "__main__":
    main()
