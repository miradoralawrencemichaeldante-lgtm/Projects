import cv2
import pytesseract
import re
import threading
import time
import numpy as np
from queue import Queue


from database import record_attendance, get_student


pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    print("❌ Camera not accessible")
    exit()

cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

print("📷 OCR Scanner running... Press 'q' to quit.")


roi_ratio = (0.15, 0.25, 0.85, 0.75)
FRAME_SKIP = 2
frame_count = 0
prev_time = time.time()

REQUIRED_STABLE_FRAMES = 8
last_id = None
stable_count = 0

ocr_queue = Queue()
ocr_result = {"id": None}


def preprocess_roi(roi):
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    kernel = np.ones((2, 2), np.uint8)
    gray = cv2.dilate(gray, kernel, iterations=1)
    gray = cv2.erode(gray, kernel, iterations=1)

    _, thresh = cv2.threshold(
        gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    return thresh


def ocr_worker():
    while True:
        roi = ocr_queue.get()
        if roi is None:
            break

        thresh = preprocess_roi(roi)
        config = (
            r'--oem 3 --psm 6 '
            r'-c tessedit_char_whitelist=0123456789'
        )

        text = pytesseract.image_to_string(thresh, config=config)
        detected_id = None

        for line in text.splitlines():
            match = re.search(r'\b24\d{4}\b', line)
            if match:
                detected_id = match.group()
                break

        ocr_result["id"] = detected_id
        ocr_queue.task_done()

threading.Thread(target=ocr_worker, daemon=True).start()


while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame_count += 1
    h, w, _ = frame.shape

    roi_x1 = int(w * roi_ratio[0])
    roi_y1 = int(h * roi_ratio[1])
    roi_x2 = int(w * roi_ratio[2])
    roi_y2 = int(h * roi_ratio[3])

    roi = frame[roi_y1:roi_y2, roi_x1:roi_x2]

    cv2.rectangle(frame, (roi_x1, roi_y1), (roi_x2, roi_y2), (255, 0, 0), 2)
    cv2.putText(frame, "Place ID inside the box",
                (roi_x1, roi_y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

    if frame_count % FRAME_SKIP == 0 and ocr_queue.empty():
        ocr_queue.put(roi.copy())

    detected_id = ocr_result["id"]

    if detected_id and detected_id.startswith("24") and len(detected_id) == 6:

        if detected_id == last_id:
            stable_count += 1
        else:
            last_id = detected_id
            stable_count = 1

        cv2.putText(frame,
            f"Detecting ID: {detected_id} ({stable_count}/{REQUIRED_STABLE_FRAMES})",
            (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

        if stable_count >= REQUIRED_STABLE_FRAMES:

            student = get_student(detected_id)

            if not student:
                cv2.rectangle(frame, (roi_x1, roi_y1), (roi_x2, roi_y2),
                              (0, 0, 255), 3)
                cv2.putText(frame, "❌ ID NOT REGISTERED",
                            (20, 120), cv2.FONT_HERSHEY_SIMPLEX,
                            1, (0, 0, 255), 3)
                print("❌ ID not found in database")

            else:
                if record_attendance(detected_id):
                    cv2.rectangle(frame, (roi_x1, roi_y1), (roi_x2, roi_y2),
                                  (0, 255, 0), 3)
                    cv2.putText(frame, "✅ ATTENDANCE RECORDED",
                                (20, 120), cv2.FONT_HERSHEY_SIMPLEX,
                                1, (0, 255, 0), 3)

                    print(f"✅ Attendance recorded for {student[1]} ({student[2]})")

                else:
                    cv2.rectangle(frame, (roi_x1, roi_y1), (roi_x2, roi_y2),
                                  (0, 0, 255), 3)
                    cv2.putText(frame, "❌ ALREADY RECORDED TODAY",
                                (20, 120), cv2.FONT_HERSHEY_SIMPLEX,
                                1, (0, 0, 255), 3)

                    print("❌ Already recorded today")

    else:
        last_id = None
        stable_count = 0
        cv2.putText(frame, "Align ID clearly",
                    (20, 60), cv2.FONT_HERSHEY_SIMPLEX,
                    0.8, (0, 0, 255), 2)

    fps = 1 / (time.time() - prev_time)
    prev_time = time.time()
    cv2.putText(frame, f"FPS: {int(fps)}",
                (20, 30), cv2.FONT_HERSHEY_SIMPLEX,
                0.8, (0, 255, 0), 2)

    cv2.imshow("Student ID OCR Scanner", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

ocr_queue.put(None)
cap.release()
cv2.destroyAllWindows()
