import sqlite3
import datetime


conn = sqlite3.connect("attendance.db")  
c = conn.cursor()


c.execute("""
CREATE TABLE IF NOT EXISTS attendance (
    id TEXT,
    date TEXT
)
""")
conn.commit()

def check_and_save_attendance(student_id):
    today = datetime.date.today().isoformat()  
  
    c.execute("SELECT * FROM attendance WHERE id=? AND date=?", (student_id, today))
    result = c.fetchone()
    if result:
        return False  
   
    c.execute("INSERT INTO attendance (id, date) VALUES (?,?)", (student_id, today))
    conn.commit()
    return True
